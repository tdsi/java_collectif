/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package smschat;

import java.io.File;
import java.io.Serializable;

/**
 *
 * @author Papa Babacar Ndiaye
 */
public class SmsChat implements Serializable{
    private String dest;
    private String expe;
    private String message;
    private File [] fichier;

    //sérialisation
    public SmsChat(String dest, String expe, String message, File[] fichier) {
        this.dest = dest;
        this.expe = expe;
        this.message = message;
        this.fichier = fichier;
    }

    public SmsChat(String message) {
        this.message = message;
    }

    public File[] getFichier() {
        return fichier;
    }

    public void setFichier(File[] fichier) {
        this.fichier = fichier;
    }
   

    public String getDest() {
        return dest;
    }

    public void setDest(String dest) {
        this.dest = dest;
    }

    public String getExpe() {
        return expe;
    }

    public void setExpe(String expe) {
        this.expe = expe;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
    /**
     * @param args the command line arguments
     */
    
    
}
