/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package smschat;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import javax.swing.JOptionPane;

/**
 *
 * @author Papa Babacar Ndiaye
 */
public class ClassMain {

    final static int port = 2015;
    final static String addr = "127.0.0.1";
    static boolean test = true;
    static boolean test2 = true;
    static Socket socketClient;
    static Socket s;
    static int nbcon = 0;

    static void lancement() {
       // new Interface();
        (new Interface()).go();
        System.out.println("Lancement du client");
        System.out.println("connection vers  " + addr + " port " + port);
        //  Socket s = null;
        try {
            s = new Socket(addr, port);
            test = false;
            System.out.println("serveur retrouve");
            Reception t = new Reception(s);
            t.start();
            Emission e = new Emission(s);
            e.start();

        } catch (IOException ex) {
            //Logger.getLogger(ClassMain.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("serveur non trouve");
        }

        if (test) {
            test2 = false;
            try {

                ServerSocket socketServeur = new ServerSocket(port);
                System.out.println("Lancement du serveur");
                while (true) {
                    socketClient = socketServeur.accept();
                    System.out.println("connection acceptee");
                    Reception t = new Reception(socketClient);
                    t.start();
                    Emission e = new Emission(socketClient);
                    e.start();

                }
            } catch (IOException ex) {
                // Logger.getLogger(ClassMain.class.getName()).log(Level.SEVERE, null, ex);
                System.out.println("conection perdue"); 
                
                JOptionPane.showMessageDialog(null, "Problme de réseau", "Connexion au réseau impossible.", JOptionPane.WARNING_MESSAGE);
            }

        }

        if (test2) {
            try {
                
                ServerSocket socketServeur = new ServerSocket(port + 1);
                System.out.println("Lancement du serveur");
                while (true) {
                    socketClient = socketServeur.accept();

                    nbcon++;

                    System.out.println("connection acceptee");
                    Reception t = new Reception(socketClient);
                    t.start();
                    Emission e = new Emission(socketClient);
                    e.start();

                }
            } catch (IOException ex) {
                // Logger.getLogger(ClassMain.class.getName()).log(Level.SEVERE, null, ex);
                System.out.println("conection perdue");
                JOptionPane.showMessageDialog(null, "Problme de réseau", "Connexion au réseau impossible.", JOptionPane.WARNING_MESSAGE);
            }
        }

    }

   // public static void main(String[] args) {
     //   lancement();
    //}
}
